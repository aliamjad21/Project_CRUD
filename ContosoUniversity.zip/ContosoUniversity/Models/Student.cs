﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics;

namespace ContosoUniversity.Models
{

    public enum Gender { M, F }
    public class Student
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }
        public string Username { get; set; }
        public string Status { get; set; }

        [DisplayFormat(NullDisplayText = "No Gender")]
        public Gender? Gender { get; set; }
        public DateTime Birthday { get; set; }

        public string Address { get; set; }

    }
}
